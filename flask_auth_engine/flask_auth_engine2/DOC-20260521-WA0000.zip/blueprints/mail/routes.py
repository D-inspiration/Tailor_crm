"""
Mail dashboard API — inbox, read, search, archive.
"""

from flask import Blueprint, request, jsonify
from ...services.mail_service import MailService
from ...core.constants import MessageStatus

mail_bp = Blueprint("comm_mail", __name__)


@mail_bp.route("/inbox", methods=["GET"])
def inbox():
    """List inbox messages (unread + read)."""
    limit = request.args.get("limit", 50, type=int)
    offset = request.args.get("offset", 0, type=int)

    service = MailService()
    messages = service.inbox(limit=limit, offset=offset)

    return jsonify({
        "messages": [
            {
                "id": m.id,
                "sender": m.sender,
                "recipient": m.recipient,
                "subject": m.subject,
                "preview": m.preview,
                "status": m.status,
                "received_at": m.received_at.isoformat(),
                "attachment_count": m.attachment_count,
                "is_spam": m.is_spam,
            }
            for m in messages
        ],
        "stats": service.stats(),
    })


@mail_bp.route("/<int:message_id>", methods=["GET"])
def get_message(message_id: int):
    """Read full message."""
    service = MailService()
    msg = service.get(message_id)
    if not msg:
        return jsonify({"error": "Message not found"}), 404

    return jsonify({
        "id": msg.id,
        "sender": msg.sender,
        "recipient": msg.recipient,
        "subject": msg.subject,
        "body": msg.body,
        "html": msg.html,
        "status": msg.status,
        "received_at": msg.received_at.isoformat(),
        "links": msg.extract_links(),
        "attachments": [
            {"filename": a.filename, "mime_type": a.mime_type, "size": a.size_bytes}
            for a in msg.attachments
        ],
    })


@mail_bp.route("/<int:message_id>/read", methods=["POST"])
def mark_read(message_id: int):
    service = MailService()
    try:
        msg = service.mark_read(message_id)
        return jsonify({"id": msg.id, "status": msg.status})
    except ValueError as e:
        return jsonify({"error": str(e)}), 404


@mail_bp.route("/<int:message_id>/archive", methods=["POST"])
def archive_message(message_id: int):
    service = MailService()
    try:
        msg = service.archive(message_id)
        return jsonify({"id": msg.id, "status": msg.status})
    except ValueError as e:
        return jsonify({"error": str(e)}), 404


@mail_bp.route("/search", methods=["GET"])
def search():
    query = request.args.get("q", "")
    if not query:
        return jsonify({"error": "Query required"}), 400

    service = MailService()
    results = service.search(query)
    return jsonify({
        "query": query,
        "count": len(results),
        "messages": [
            {"id": m.id, "sender": m.sender, "subject": m.subject, "preview": m.preview}
            for m in results
        ],
    })
