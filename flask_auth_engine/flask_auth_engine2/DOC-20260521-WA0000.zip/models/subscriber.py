"""
Subscriber entity — subscription authority merged into comm platform.
"""

from sqlalchemy import Column, String, JSON
from .base import BaseModel
from ..core.constants import SubscriberStatus


class Subscriber(BaseModel):
    """
    Represents an audience member with subscription status.
    """

    __tablename__ = "comm_subscribers"

    email = Column(String(255), unique=True, nullable=False, index=True)
    status = Column(String(20), default=SubscriberStatus.PENDING.value, nullable=False)
    tags = Column(JSON, default=list)           # Audience segmentation
    plan = Column(String(50), default="free")  # Subscription tier
    source = Column(String(100), nullable=True) # Acquisition channel

    # ------------------------------------------------------------------
    # Lifecycle methods
    # ------------------------------------------------------------------
    def subscribe(self) -> "Subscriber":
        self.status = SubscriberStatus.ACTIVE.value
        return self.save()

    def unsubscribe(self) -> "Subscriber":
        self.status = SubscriberStatus.UNSUBSCRIBED.value
        return self.save()

    def change_plan(self, new_plan: str) -> "Subscriber":
        self.plan = new_plan
        return self.save()

    def add_tag(self, tag: str) -> "Subscriber":
        if tag not in (self.tags or []):
            self.tags = (self.tags or []) + [tag]
        return self.save()
