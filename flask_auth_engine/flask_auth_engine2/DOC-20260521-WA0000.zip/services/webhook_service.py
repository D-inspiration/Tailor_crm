"""
Webhook orchestration service.
Coordinates verification, logging, parsing, and downstream triggers.
"""

from typing import Dict, Any
from ..services.parser_service import ParserService
from ..services.mail_service import MailService
from ..services.notification_service import NotificationService
from ..models.webhook_log import WebhookLog
from ..core.config import CommConfig


class WebhookService:
    """
    Encapsulated webhook processing pipeline.
    Internal state (_log_id, _verified) protected.
    """

    def __init__(self):
        self._parser = ParserService()
        self._mail = MailService()
        self._notifier = NotificationService()
        self._log: WebhookLog | None = None

    # ------------------------------------------------------------------
    # Pipeline
    # ------------------------------------------------------------------
    def process(self, payload: Dict[str, Any], signature: str, headers: Dict[str, str]) -> dict:
        """
        Full lifecycle: detect → verify → log → parse → ingest → notify.
        """
        provider_name = self._parser.detect_provider(headers)

        # 1. Log raw payload (immutable audit trail)
        self._log = WebhookLog(
            payload=str(payload),
            provider=provider_name,
            signature=signature,
        ).save()

        # 2. Parse and verify
        try:
            normalized = self._parser.parse(payload, signature, provider_name)
            self._log.mark_verified()
        except PermissionError:
            return {"status": "rejected", "reason": "verification_failed", "log_id": self._log.id}

        # 3. Ingest as Message
        message = self._mail.ingest(normalized)

        # 4. Trigger notifications / automations
        self._notifier.on_new_message(message)

        return {
            "status": "accepted",
            "message_id": message.id,
            "provider": provider_name,
            "log_id": self._log.id,
        }
