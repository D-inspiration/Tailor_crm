"""
Configuration overlay.
Reads from the existing Flask app.config without writing into it.
All keys are namespaced with COMM_ prefix to avoid collision.
"""

from typing import Optional
from flask import Flask


class CommConfig:
    """Namespace-isolated configuration reader."""

    _app: Optional[Flask] = None

    # Defaults
    DEFAULTS = {
        "COMM_RESEND_WEBHOOK_SECRET": None,
        "COMM_SES_TOPIC_ARN": None,
        "COMM_MAX_ATTACHMENT_SIZE": 25 * 1024 * 1024,  # 25MB
        "COMM_SPAM_THRESHOLD": 70,
        "COMM_PREVIEW_LENGTH": 100,
        "COMM_DEFAULT_PROVIDER": "resend",
        "COMM_ENABLE_AI_SUMMARY": False,
    }

    @classmethod
    def load(cls, app: Flask) -> None:
        cls._app = app
        # Inject only missing defaults (no overwrite of existing keys)
        for key, value in cls.DEFAULTS.items():
            app.config.setdefault(key, value)

    @classmethod
    def get(cls, key: str):
        if cls._app is None:
            raise RuntimeError("CommConfig not loaded. Call init_comm_platform(app) first.")
        return cls._app.config.get(key, cls.DEFAULTS.get(key))
