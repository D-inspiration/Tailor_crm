"""
Attachment metadata — files stored externally (S3/MinIO), metadata here.
"""

from sqlalchemy import Column, String, Integer, ForeignKey
from sqlalchemy.orm import relationship
from .base import BaseModel


class Attachment(BaseModel):
    """Represents a file attached to a message."""

    __tablename__ = "comm_attachments"

    filename = Column(String(255), nullable=False)
    path = Column(String(500), nullable=False)      # Storage URL/path
    size_bytes = Column(Integer, default=0)
    mime_type = Column(String(100), nullable=True)

    message_id = Column(Integer, ForeignKey("comm_messages.id"), nullable=False)
    message = relationship("Message", back_populates="attachments")
