"""
Dashboard metrics API — stats, activity feed, health.
"""

from flask import Blueprint, jsonify
from ...services.mail_service import MailService
from ...services.subscription_service import SubscriptionService
from ...services.webhook_service import WebhookService

dashboard_bp = Blueprint("comm_dashboard", __name__)


@dashboard_bp.route("/stats", methods=["GET"])
def stats():
    """Aggregate platform statistics."""
    mail = MailService()
    subs = SubscriptionService()

    return jsonify({
        "messages": mail.stats(),
        "subscribers": subs.stats(),
    })


@dashboard_bp.route("/health", methods=["GET"])
def health():
    """Service health check."""
    return jsonify({"status": "ok", "service": "comm_platform"})
