"""
Webhook audit trail.
Every inbound webhook is logged for debugging and replay.
"""

from datetime import datetime
from sqlalchemy import Column, Text, String, Boolean, DateTime
from .base import BaseModel


class WebhookLog(BaseModel):
    """Immutable log of raw webhook payloads."""

    __tablename__ = "comm_webhook_logs"

    payload = Column(Text, nullable=False)
    provider = Column(String(20), nullable=False)
    signature = Column(String(500), nullable=True)
    verified = Column(Boolean, default=False, nullable=False)
    processed_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    # ------------------------------------------------------------------
    # Methods
    # ------------------------------------------------------------------
    def mark_verified(self) -> "WebhookLog":
        self.verified = True
        return self.save()
